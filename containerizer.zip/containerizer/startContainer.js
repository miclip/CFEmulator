## \garden-windows\Containerizer\containerizer> .\bin\containerizer.exe --machineip 10.0.2.15 --port 1788

## Create Container
var xhr = new XMLHttpRequest();
xhr.open("POST", "http://localhost:1788/api/containers", true);
xhr.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');
var data = {
  "Handle": "hwchandle",
  "grace_time": 300000000000,
  "Properties": {"ContainerPort:8080":"64055", "ContainerPort:2222":"64061"},
  "Env": null,
  "Limits": {
    "cpu_limits": {
      "limit_in_shares": 9999
    },
    "memory_limits": {
      "limit_in_bytes": 1073741824
    },
    "disk_limits": {
      "byte_hard": 1073741824
    }
  },
  "bind_mounts": []
}
xhr.send(JSON.stringify(data));


## Copy hwc.exe and webapp

## Start HWC Process
var websocket = new WebSocket("ws://localhost:1788/api/containers/hwchandle/run")
websocket.onmessage = function(d) { console.log(d); }
var data = {
  "type": "run",
  "pspec": {
    "path": "C:\\containerizer\\1409DF6E45C1C89E09\\bin\\hwc.exe",
    "args": ["-appRootPath", "C:\\containerizer\\1409DF6E45C1C89E09\\user\\app"],
    "env": ["PORT=8080"]
  },
  "data": null
}
websocket.send(JSON.stringify(data));


## Delete Container
var xhr = new XMLHttpRequest();
xhr.open("POST", "http://localhost:1788/api/containers/hwchandle/stop", true);
xhr.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');
xhr.send(JSON.stringify({}));

var xhr = new XMLHttpRequest();